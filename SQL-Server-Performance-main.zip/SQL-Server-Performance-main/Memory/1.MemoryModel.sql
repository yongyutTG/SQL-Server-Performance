USE master;
GO

SELECT sql_memory_model,sql_memory_model_desc FROM sys.dm_os_sys_info;
GO
