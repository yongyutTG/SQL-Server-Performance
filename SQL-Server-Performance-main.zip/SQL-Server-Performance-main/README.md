# SQL-Server-Performance

ใช้ฐานข้อมูลตัวอย่าง [Adventureworks](https://learn.microsoft.com/en-us/sql/samples/adventureworks-install-configure?view=sql-server-ver16&tabs=ssms)
