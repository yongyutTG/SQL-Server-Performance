-- Module 1 - Demo 2 - File 2
USE TSQL;
GO

SELECT @@SPID as select_session_id;
GO

SELECT companyname FROM Sales.Customers;

